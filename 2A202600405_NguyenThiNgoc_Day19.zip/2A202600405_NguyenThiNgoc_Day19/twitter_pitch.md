TWITTER PITCH — TrustLayerAI

---

## Twitter Pitch (dưới 280 ký tự)

> Anh Minh (IT Manager Techcombank) tìm ra khoảng 23% chatbot HR trả lời sai sau 6 tháng — không ai hề biết. TrustLayerAI monitor 100% queries real-time, triển khai 2 tiếng. 3 paying customers: $1.200 MRR (tháng 2). LTV/CAC 5.2x. Gọi $300K seed → $10K MRR/12 tháng.

*(Đếm: 265 ký tự — pass)*

---

## Script đọc to (45–60 giây)

"Anh Minh, IT Manager ở Techcombank, tìm ra khoảng 23% chatbot HR sai sau 6 tháng đi vào hoạt động — thực sự không ai biết chuyện này.

Đây là vấn đề của giai đoạn thứ hai áp dụng AI: đã triển khai xong, nhưng không có công cụ đo lường chất lượng.

TrustLayerAI hoạt động như lớp monitoring thực tế cho RAG chatbot — triển khai khoảng 2 tiếng, không cần IT ticket. Mỗi query được score real-time theo 5 chiều: faithfulness, hallucination risk, policy compliance.

Hiện có 3 paying customers: Techcombank, Bảo Việt, Retail Central — tổng MRR $1.200 tháng 2, LTV/CAC 5.2x.

Chúng tôi đang gọi $300K seed để mở rộng lên 20 enterprise customers và đạt $10K MRR trong 12 tháng."

*(Thời gian đọc: ~50 giây — nằm trong sweet spot 45–60 giây)*
