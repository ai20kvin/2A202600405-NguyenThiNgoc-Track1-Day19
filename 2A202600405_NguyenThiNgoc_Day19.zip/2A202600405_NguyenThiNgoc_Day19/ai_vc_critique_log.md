AI VC CRITIQUE LOG — TrustLayerAI

---

## PITCH GỐC (trước critique)

**Pitch Memo gốc:**

TrustLayerAI là công cụ đánh giá chatbot nội bộ cho doanh nghiệp.
Doanh nghiệp triển khai RAG chatbot nhưng không biết chất lượng ra sao.
Chúng tôi cung cấp dashboard monitoring real-time để đo hallucination, faithfulness.
3 pilots đang chạy, MRR $1.200. Gọi $300K seed.

**Twitter Pitch gốc:**

TrustLayerAI giúp doanh nghiệp đánh giá chatbot nội bộ RAG. Monitoring real-time, phát hiện hallucination. 3 pilots, $1.200 MRR. Gọi $300K seed để mở rộng.

---

## CONVERSATION VỚI AI VC (Sequoia Partner Persona)

**Prompt đã dùng** *(từ 4.1 của handbook)*:

> Act as a Partner at Sequoia Capital who has heard 50 AI startup pitches this week. You're tired, skeptical, and have seen every variant of "we're using LLMs to disrupt X."
> Critique it ruthlessly on 5 points...

---

### AI FEEDBACK NHẬN ĐƯỢC:

---

**1. THE 8-SECOND TEST**

*AI critique:*
> "TrustLayerAI là công cụ đánh giá chatbot" — this fails the 8-second test immediately. You led with what you ARE, not what CHANGES for the customer. I don't feel the pain in 8 seconds. Compare to: "23% of HR chatbot answers at your company are wrong — and no one knows." THAT opens with a punch. Your opening buries the lede. Rewrite the first sentence entirely.

**→ Quyết định: ACCEPT**

*Lý do:* AI đúng hoàn toàn. Câu mở đầu gốc là "công cụ đánh giá" — quá kỹ thuật, không tạo tension. Con số 23% là discovery thực từ pilot và nên đứng đầu tiên để gây chú ý ngay lập tức. Đã sửa trong pitch final.

---

**2. THE INSIGHT TEST**

*AI critique:*
> The insight you're implying — "enterprises deploy RAG but have no quality monitoring" — is okay but not sharp enough. Every observability startup says "you can't manage what you can't measure." What's the COUNTER-INTUITIVE part? Why does this specific problem exist NOW that didn't 18 months ago? You hint at it (LLM judge cost dropped 10x) but you buried it in "Why Now." That insight should be the CORE of your pitch — not a supporting bullet.

** Quyết định: PARTIAL ACCEPT**

*Lý do:* AI đúng rằng insight về cost reduction của LLM judge cần được đẩy lên cao hơn. Tuy nhiên, tôi không đồng ý rằng đây là insight duy nhất. Insight sâu hơn là: doanh nghiệp đang ở phase 2 của AI adoption ("đã deploy, giờ lo chất lượng") — đây là behavioral shift không chỉ là cost issue. Đã bổ sung cả hai điểm này vào pitch final nhưng giữ nguyên framing phase-of-adoption vì nó differentiate hơn.

---

**3. THE OPENAI THREAT**

*AI critique:*
> "If OpenAI shipped an eval dashboard tomorrow, why would you survive?" Your current pitch doesn't answer this. "We integrate with existing infrastructure" is not a moat — OpenAI can do that too. You need to articulate WHY an enterprise in Vietnam/SEA would trust YOU over OpenAI's native tooling. Is it data residency? Local compliance? Deep integration with on-premise RAG? Pick one and make it loud.

** Quyết định: ACCEPT**

*Lý do:* Đây là điểm yếu thực sự trong pitch gốc — hoàn toàn không đề cập moat. Sau khi suy nghĩ, moat thực sự của TrustLayerAI là: (1) **data residency** — enterprise SEA không muốn query nội bộ đi qua server OpenAI để evaluate; (2) **workflow integration** với 5 RAG framework phổ biến tại SEA mà OpenAI không support native. Đã thêm vào pitch final ở section Solution và tạo câu trả lời sẵn cho câu hỏi này.

---

**4. THE NUMBERS TEST**

*AI critique:*
> $1.200 MRR with 3 pilots is real but weak as a standalone number. You need to show the TRAJECTORY. Is this month 1 or month 6? What was MRR at month 1? Without a growth rate, $1.200 MRR sounds like you've been flat for 6 months. Also: LTV/CAC of 5.2x "projected" is not the same as 5.2x "observed." Label this correctly or a Series A VC will call you out. For Seed, this is acceptable — but be ready to defend the projection methodology.

** Quyết định: PARTIAL ACCEPT**

*Lý do:* AI đúng về việc cần contextualize MRR (đây là tháng 2 kể từ khi có paying customers — tháng 1 là $400). Tuy nhiên tôi không đồng ý với framing "weak" — $1.200 MRR với 3 enterprise paying customers sau 2 tháng là signal khá tốt cho Seed, vì enterprise sales cycle thường 60–90 ngày. Đã điều chỉnh pitch để nêu rõ "tháng 2 kể từ commercial launch" và label LTV/CAC là "projected based on pilot deal structure" cho minh bạch.

---

**5. THE WEAKEST LINE**

*AI critique:*
> Weakest line: "không cần thay đổi hạ tầng hiện có."
> This sounds like every middleware vendor ever. It's a feature, not a benefit. Rewrite as: "Triển khai trong 2 giờ — không cần IT ticket, không cần data migration." Specificity about deployment friction is what enterprise buyers actually fear. Give them the number.

** Quyết định: ACCEPT**

*Lý do:* AI hoàn toàn đúng. "Không cần thay đổi hạ tầng" là generic benefit claim. "Triển khai trong 2 giờ" là concrete và believable (dựa trên kinh nghiệm pilot thực — pilot đầu setup mất 1.5 giờ). Đã sửa trong pitch final.

---

## PITCH FINAL (sau khi iterate)

### Pitch Memo Final:

---

## 1. THE PROBLEM

Anh Minh, IT Manager ở một tập đoàn 2.000 nhân viên tại TP.HCM, phát hiện khoảng 23% câu trả lời từ chatbot HR nội bộ có hallucination risk cao — **sau 6 tháng đi vào hoạt động, thực sự không ai biết chuyện này**.

Đây không phải case riêng lẻ: nhiều doanh nghiệp đang ở giai đoạn "đã triển khai chatbot RAG xong, giờ bắt đầu lo về chất lượng" mà không có công cụ đo lường, dẫn đến việc hoặc tin tưởng 100% vào AI hoặc phải từ bỏ hoàn toàn.

---

## 2. THE INSIGHT

Vấn đề thực sự không phải là chatbot trả lời sai mà bởi vì **doanh nghiệp đang ở giai đoạn thứ hai của việc áp dụng AI**: "đã triển khai xong, giờ cần quan tâm chất lượng" nhưng không có công cụ đo lường, khiến cả tổ chức hoặc chấp nhận tin vào AI hoặc phải từ bỏ hoàn toàn.

Đây là lần đầu tiên chi phí chạy LLM judge giảm khoảng 10 lần (GPT-4o mini: $0.15/1000 queries) khiến việc đánh giá 100% queries trở nên khả thi về mặt kinh tế — thay vì chỉ sample 5% như trước đây.

---

## 3. THE SOLUTION

TrustLayerAI hoạt động như lớp monitoring trong môi trường thực tế cho RAG/Enterprise Search chatbot — **có thể triển khai trong khoảng 2 tiếng, không cần IT ticket hay di chuyển dữ liệu**.

Không giống như RAGAS hay DeepEval chỉ chạy offline một lần, TrustLayerAI đánh giá real-time mỗi query theo 5 chiều: Faithfulness, Hallucination Risk, Policy Compliance, Relevancy, Context Recall — có dashboard cảnh báo ngay khi thấy pattern bất thường.

**AI hỗ trợ gì:** Mô hình judge nhỏ (GPT-4o mini) chạy song song, so sánh output với tài liệu nguồn, tự động gắn cờ các queries nghi ngờ — chi phí khoảng $0.15/1000 queries, giảm 10 lần so với 12 tháng trước.

**Lợi thế cạnh tranh:** (1) Dữ liệu không rời khỏi infrastructure của khách hàng; (2) Có sẵn connector cho 5 RAG framework phổ biến nhất Đông Nam Á mà các Big Tech chưa hỗ trợ đầy đủ.

---

## 4. WHY NOW

Chi phí chạy LLM judge giảm 10x trong 12 tháng qua (GPT-4o mini, Claude Haiku), lần đầu tiên khả thi về kinh tế để đánh giá **100% queries** thay vì chỉ sample.

Đồng thời, làn sóng enterprise tại Đông Nam Á triển khai RAG chatbot đang bước vào giai đoạn *"đã deploy xong, giờ lo chất lượng"* — nhu cầu observability xuất hiện đúng thời điểm sản phẩm có thể đáp ứng.

---

## 5. TRACTION / PROOF

- **3 paying customers:** Techcombank (2.100 nhân viên), Bảo hiểm Bảo Việt (1.800 nhân viên), Tập đoàn Retail Central (600 nhân viên) — tổng 4.500 employees
- **Aha moment:** Anh Minh, IT Manager tại Techcombank, sau 7 ngày dùng TrustLayerAI phát hiện 23% câu trả lời từ bot HR có Hallucination Risk > 0.7 — con số mà team của anh đã bỏ qua trong 6 tháng
- **NPS:** 72 (benchmark B2B SaaS: 40–50) — measured từ 15 users tại 3 pilots
- **MRR hiện tại:** $1.200/tháng (Month 2 kể từ commercial launch, Month 1: $400)
- **LTV/CAC:** 5.2x dựa trên deal structure $400/tháng, CAC $2.000 qua outbound enterprise — payback 5 tháng
- **Usage:** 12,500 queries evaluated trong 30 ngày qua, average 417 queries/ngày

---

## 6. THE ASK

Gọi **$300.000 USD Seed** để:
1. Mở rộng lên 20 khách hàng enterprise trong 9 tháng (target: MRR $8.000+)
2. Build thêm connector cho top 5 RAG framework phổ biến tại SEA (LlamaIndex, LangChain, Azure AI Search, Vertex AI Search, Haystack)
3. Tuyển 1 Enterprise Sales Rep có background B2B SaaS tại VN/SG

**Milestone 12 tháng:** $10.000 MRR, 15+ paying enterprise customers, sẵn sàng Series A conversation.

---

### Twitter Pitch Final:

> Anh Minh (IT Manager Techcombank) phát hiện 23% chatbot HR sai sau 6 tháng — không ai biết. TrustLayerAI monitor 100% queries real-time, deploy 2 giờ. 3 paying customers: $1.200 MRR (Month 2). LTV/CAC 5.2x. Gọi $300K seed → $10K MRR/12 tháng.

*(265 ký tự — pass)*

---

## SELF-EVALUATION CHECKLIST (§3.6)

```
[✓] Mở đầu trong 8 giây gây được sự chú ý
    → "Anh Minh, IT Manager ở Techcombank, tìm ra khoảng 23% chatbot HR trả lời sai sau 6 tháng — không ai hề biết" — số cụ thể + insight bất ngờ

[✓] Có ít nhất 1 insight phản trực giác
    → "doanh nghiệp đang ở giai đoạn thứ hai của việc áp dụng AI: đã triển khai xong, giờ cần quan tâm chất lượng"
    → + LLM judge cost giảm 10 lần tạo timing window

[✓] Có ít nhất 2 con số cụ thể
    → khoảng 23% trả lời sai, $1.200 MRR, 5.2x LTV/CAC, 2 tiếng deployment, 7 ngày pilot

[✓] Differentiator rõ
    → Real-time vs offline (RAGAS/DeepEval); data residency moat; native SEA connectors
    → OpenAI threat answer: data không rời khỏi infrastructure khách hàng

[✓] Ask cụ thể: $300K, để đạt 20 customers / $10K MRR trong 12 tháng

[✓] Đọc to dưới 60 giây: ~50 giây (đã test)

[✓] Match audience Seed VC: tập trung vision + early traction + TAM signal,
    không đi sâu unit economics phức tạp như Series A
```

**Kết quả: PASS đủ 7/7 mục.**
