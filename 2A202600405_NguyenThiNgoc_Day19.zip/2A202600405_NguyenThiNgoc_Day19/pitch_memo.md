PITCH MEMO — TrustLayerAI

---

## 1. THE PROBLEM

Anh Minh, IT Manager ở một tập đoàn 2.000 nhân viên tại TP.HCM, phát hiện khoảng 23% câu trả lời từ chatbot HR nội bộ đang trả lời sai — **sau 6 tháng đi vào hoạt động, thực sự không ai biết chuyện này**.

Đây không phải case riêng lẻ: nhiều doanh nghiệp đang ở giai đoạn "đã triển khai chatbot RAG xong, giờ bắt đầu lo về chất lượng" mà không có công cụ đo lường, dẫn đến việc hoặc tin tưởng 100% vào AI hoặc phải từ bỏ hoàn toàn.

---

## 2. THE INSIGHT

Vấn đề thực sự không phải là chatbot trả lời sai mà bởi vì **doanh nghiệp đang ở giai đoạn thứ hai của việc áp dụng AI**: "đã triển khai xong, giờ cần quan tâm chất lượng" nhưng không có công cụ đo lường, khiến cả tổ chức hoặc chấp nhận tin vào AI hoặc phải từ bỏ hoàn toàn.

Đây là lần đầu tiên chi phí chạy LLM judge giảm khoảng 10 lần (GPT-4o mini: $0.15/1000 queries) khiến việc đánh giá 100% queries trở nên khả thi về mặt kinh tế — thay vì chỉ sample 5% như trước đây.

---

## 3. THE SOLUTION

TrustLayerAI hoạt động như lớp monitoring trong môi trường thực tế cho RAG/Enterprise Search chatbot — **có thể triển khai trong khoảng 2 tiếng, không cần IT ticket hay di chuyển dữ liệu**.

Không giống như RAGAS hay DeepEval chỉ chạy offline một lần, TrustLayerAI đánh giá real-time mỗi query theo 5 chiều: Faithfulness, Hallucination Risk, Policy Compliance, Relevancy, Context Recall — có dashboard cảnh báo ngay khi thấy pattern bất thường.

**AI hỗ trợ gì:** Mô hình judge nhỏ (GPT-4o mini) chạy song song, so sánh output với tài liệu nguồn, tự động gắn cờ các queries nghi ngờ — chi phí khoảng $0.15/1000 queries, giảm 10 lần so với 12 tháng trước.

**Lợi thế cạnh tranh:** (1) Dữ liệu không rời khỏi infrastructure của khách hàng; (2) Có sẵn connector cho 5 RAG framework phổ biến nhất Đông Nam Á mà các Big Tech chưa hỗ trợ đầy đủ.

---

## 4. WHY NOW

Chi phí chạy LLM judge giảm 10x trong 12 tháng qua (GPT-4o mini, Claude Haiku), lần đầu tiên khả thi về kinh tế để đánh giá **100% queries** thay vì chỉ sample.

Đồng thời, làn sóng enterprise tại Đông Nam Á triển khai RAG chatbot đang bước vào giai đoạn *"đã deploy xong, giờ lo chất lượng"* — nhu cầu observability xuất hiện đúng thời điểm sản phẩm có thể đáp ứng.

---

## 5. TRACTION / PROOF

- **3 paying customers:** Techcombank (2.100 nhân viên), Bảo hiểm Bảo Việt (1.800 nhân viên), Tập đoàn Retail Central (600 nhân viên) — tổng 4.500 employees
- **Aha moment:** Anh Minh, IT Manager tại Techcombank, sau 7 ngày dùng TrustLayerAI phát hiện 23% câu trả lời từ bot HR có Hallucination Risk > 0.7 — con số mà team của anh đã bỏ qua trong 6 tháng
- **NPS:** 72 (benchmark B2B SaaS: 40–50) — measured từ 15 users tại 3 pilots
- **MRR hiện tại:** $1.200/tháng (Month 2 kể từ commercial launch, Month 1: $400)
- **LTV/CAC:** 5.2x dựa trên deal structure $400/tháng, CAC $2.000 qua outbound enterprise — payback 5 tháng
- **Usage:** 12,500 queries evaluated trong 30 ngày qua, average 417 queries/ngày

---

## 6. THE ASK

Gọi **$300.000 USD Seed** để:
1. Mở rộng lên 20 khách hàng enterprise trong 9 tháng (target: MRR $8.000+)
2. Build thêm connector cho top 5 RAG framework phổ biến tại SEA (LlamaIndex, LangChain, Azure AI Search, Vertex AI Search, Haystack)
3. Tuyển 1 Enterprise Sales Rep có background B2B SaaS tại VN/SG

**Milestone 12 tháng:** $10.000 MRR, 15+ paying enterprise customers, sẵn sàng Series A conversation.
